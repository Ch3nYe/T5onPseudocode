from tokenizers import ByteLevelBPETokenizer
from transformers import RobertaTokenizerFast
MAX_FUNC_TOKENS = 50
MAX_VAR_TOKENS  = 100

paths = ['code.txt', 'comment.txt']

# Initialize a tokenizer
tokenizer = ByteLevelBPETokenizer()

def tokenizer_init(tokenizer_name_or_path="./HexT5Tokenizer"):
    MAX_EXTRA_TOKENS = 100
    LANGUAGE_LABEL = ["<en>", "<idap>"]
    VAR_LABEL = [f"<var_{i}>" for i in range(MAX_VAR_TOKENS)]
    FUNC_LABEL = [f"<func_{i}>" for i in range(1,MAX_FUNC_TOKENS)] + ["<func>"]
    UKN_LABEL = ["<ukn>"]
    SPEC_LABEL = ["<pad>", "<s>", "</s>", "<unk>", "<mask>"]
    EXTRA_LABEL = [f"<extra_id_{i}>" for i in range(MAX_EXTRA_TOKENS - 1, -1 ,-1)]
    LABELS = LANGUAGE_LABEL + VAR_LABEL + FUNC_LABEL + UKN_LABEL + SPEC_LABEL + EXTRA_LABEL
    tokenizer = RobertaTokenizerFast(vocab_file="hext5_32000/hext5-50-100-vocab.json" \
        , merges_file="hext5_32000/hext5-50-100-merges.txt")
    tokenizer.add_special_tokens({"additional_special_tokens":LABELS})
    tokenizer.save_pretrained(tokenizer_name_or_path)
    return tokenizer


def add_special_tokens(tokenizer, MAX_FUNC_TOKENS = 50, MAX_VAR_TOKENS = 100):
# append the special tokens
    tokenizer.add_special_tokens(["<s>", "<pad>", "</s>", "<unk>", "<mask>"])

    # append the function tokens and variable tokens into the tokenizer
    tokenizer.add_special_tokens(["<func>","<ukn>"])
    tokenizer.add_special_tokens([f"<func_{i}>"for i in range(1,MAX_FUNC_TOKENS)])
    tokenizer.add_special_tokens([f"<var_{i}>" for i in range(MAX_VAR_TOKENS)])

# Customize training
tokenizer.train(files=paths, vocab_size=32000, min_frequency=5, special_tokens=[
    "<pad>",
    "<s>",
    "</s>",
    "<unk>",
    "<mask>",
    "<ukn>",
    "<func>"] + [ f"<func_{i}>"for i in range(1,MAX_FUNC_TOKENS)]
    + [f"<var_{i}>" for i in range(MAX_VAR_TOKENS)])

# Save files to disk
tokenizer.save_model("./hext5_32000", f"hext5-{MAX_FUNC_TOKENS}-{MAX_VAR_TOKENS}")

print(
    tokenizer.encode("<s> hello <unk> Don't you love 🤗 Transformers <mask> yes . </s>").tokens
)
